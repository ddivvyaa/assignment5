<?php
	/*
		Plugin Name: DivyaActionPlugin
        Version: 1.0
        name: Divya Gupta 8622600
	*/

	// function for display number
	function display($number){
        
        //request sent to API for data
		$request = wp_remote_get( 'http://history.muffinlabs.com/date' ); 
		if( is_wp_error( $request ) ) { 
            //error return
		  return false; 
	}

	$body = wp_remote_retrieve_body( $request ); 
    // taking data from json
	$data = json_decode( $body ); 
//		if condition on empty
		if( !empty( $data ) ) {	

		if (is_array($data) || is_object($data)) 
			{
//            printing array of output
				print_r($data->data->Events[1]->text); 
				print_r($data->data->Events[1]->year); 
			}
		}
	}
//adding action
	add_action('wp_footer', 'display');
?>
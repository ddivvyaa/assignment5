<?php
/*
 Plugin Name: Promotion 
 Version: 1.0
 name: Divya Gupta 8622600
*/
// short code for adding function
add_shortcode('promo', 'promotioncode');	
//creating function 
function promotioncode()	
{
  $post= strtotime(get_the_date()); 
 //using current time
 $present= time(); 
 $interval = $present - $post;
	   
//time interval in seconds
if($interval > 152600) { 
 return 'The Code Is Expired';  
 } else {
//    returning output
    return 'PROMONUMBER'; 
	}
	}
?>

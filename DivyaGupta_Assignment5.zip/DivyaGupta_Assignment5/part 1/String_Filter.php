<?php
/*
Plugin Name: StringFilter
Version: 1.0
name: Divya Gupta 8622600
*/
//initializing the function
function replace_string ($str) {
	$filter = array(
//        replacing the content
		'link' => '<a href="https://www.google.com/">google</a>', 
		'WP' => '<p>wordpress</p>', 
		'language' => '<p>php</p>' 
	);

	$str = str_replace(array_keys($filter), $filter, $str; 
//	 returning the output string
                       return $str; 
	}

add_filter ('pre_comment_content', 'replace_string'); 
?>
<?php
/*
Plugin Name: CountWords
\Version: 1.0
name: Divya Gupta 8622600
*/
//counting the number of words in post
function CountingFilter ($number_of_words) {
	return $number_of_words . " (" . str_word_count($number_of_words) . " words)"; 
}

// calling function
	add_Filter("the_content", "CountingFilter");
?>